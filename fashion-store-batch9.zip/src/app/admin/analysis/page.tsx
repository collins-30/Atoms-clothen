import AnalysisView from "@/components/admin/AnalysisView";
import { getOrderAnalysis } from "@/server/admin-stats";

export default async function AdminAnalysis() {
  const data = await getOrderAnalysis();
  return <AnalysisView data={data} />;
}
