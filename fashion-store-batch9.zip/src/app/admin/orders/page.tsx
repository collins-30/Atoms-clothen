import AdminOrdersView from "@/components/admin/AdminOrdersView";
import { getAdminOrders } from "@/server/admin-orders-data";

export default async function AdminOrders() {
  const orders = await getAdminOrders();
  return <AdminOrdersView orders={orders} />;
}
